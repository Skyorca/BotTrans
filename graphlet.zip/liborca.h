#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cassert>
#include <ctime>
#include <iostream>
#include <fstream>
#include <set>
#include <unordered_map>
#include <algorithm>

#include <Python.h>
using namespace std;

PyObject * motif_counts_wrap(PyObject *self, PyObject *args);

