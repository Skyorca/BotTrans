import sys
sys.path.append("../..")
import orca
import networkx as nx
from MultiCross.dataloader import MultiSrcAndTarLoader
import argparse
import torch
import scipy.sparse as sp
import numpy as np
import networkx as nx
from grakel.kernels import WeisfeilerLehman, VertexHistogram
from sklearn.svm import SVC
from sklearn.metrics import f1_score, roc_auc_score, average_precision_score


tgt_name = "0"
for src_idx in range(0,10):
    src_tgt_idx_loader, src_tgt_data = MultiSrcAndTarLoader(tgt_idx=tgt_name, src_idx=str(src_idx),
                                                            batch_size=64,device="cpu")
    data = src_tgt_data[0]
    edge_index = data.edge_index.cpu().numpy()
    edge_weight = np.ones_like(edge_index[0,:])
    n_node = data.x.shape[0]
    sp_edge_index = sp.coo_matrix((edge_weight,(edge_index[0,:],edge_index[1,:])),shape=(n_node, n_node))
    g = nx.from_scipy_sparse_array(sp_edge_index)
    counts = orca.orbit_counts("node", 5, g)
    print(src_idx)
    print('Counts: ', counts)
    print(f'Number of nodes: {len(counts)}')
    print(f'Number of graphlets: {len(counts[0])}')
    graphlet_vec = np.array(counts)
    np.save(f"../../data/{src_idx}/raw/group{src_idx}_graphlet",graphlet_vec)


