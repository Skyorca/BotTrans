import scipy.io as sio
import os
import pandas as pd
import torch
import scipy.sparse as sp
import numpy as np

all_folders = os.listdir()
for folder in all_folders:
    if "mat" in folder: continue
    edges  = pd.read_csv(folder+f"/raw/group{folder}_edges_new.csv")
    feats  = pd.read_csv(folder+f"/raw/group{folder}_raw_feat.csv")
    labels = pd.read_csv(folder+f"/raw/group{folder}_nodes.csv")
    # user -> id
    id_map = {}
    id_ = 0
    for user in labels['id'].tolist():
        id_map[user] = id_
        id_ += 1
    # id -> user
    id_map_r = {id: user for user, id in id_map.items()}
    # replace
    feats['id'] = feats['id'].map(lambda x: id_map[x])
    labels['id'] = labels['id'].map(lambda x: id_map[x])
    edges['source'] = edges['source'].map(lambda x: id_map[x])
    edges['target'] = edges['target'].map(lambda x: id_map[x])
    # get edge index
    edge_index = edges[['source', 'target']].values.T
    feats.set_index(['id'], inplace=True)
    labels.set_index(['id'], inplace=True)
    numerical_feats = ['followers_count', 'following_count', 'active_days', 'name_len', 'uname_len', 'tweet_count',
                       'listed_count']
    category_feats = ['protected', 'verified', 'picture']
    num_property_embedding = torch.FloatTensor(feats[numerical_feats].values)
    cat_property_embedding = torch.FloatTensor(feats[category_feats].values)
    # 在Model中再分开numerical和category
    x = torch.cat([num_property_embedding, cat_property_embedding], dim=1)
    x = sp.lil_matrix(x.numpy())
    y = torch.LongTensor(labels['label'].tolist()).numpy()
    edge_index = torch.LongTensor(edge_index).numpy()
    edge_index_sp = sp.csr_matrix((np.ones_like(edge_index[0,:].squeeze()),(edge_index[0,:].squeeze(), edge_index[1,:].squeeze())),shape=(x.shape[0], x.shape[0]))
    sio.savemat(f"{folder}.mat",{"Attributes":x,"Network":edge_index_sp,"Label":y})

